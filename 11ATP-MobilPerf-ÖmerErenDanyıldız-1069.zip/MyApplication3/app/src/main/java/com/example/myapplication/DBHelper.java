package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, surname TEXT, username TEXT UNIQUE, password TEXT, birthdate TEXT, city TEXT, profile_image BLOB)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    public boolean insertUser(String name, String surname, String username, String password, String birthdate, String city, byte[] profileImage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("surname", surname);
        cv.put("username", username);
        cv.put("password", password);
        cv.put("birthdate", birthdate);
        cv.put("city", city);
        cv.put("profile_image", profileImage);
        long result = db.insert("users", null, cv);
        return result != -1;
    }

    public Cursor loginUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
    }

    public boolean updateUser(int id, String name, String surname, String password, String birthdate, String city, byte[] profileImage) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("surname", surname);
        cv.put("password", password);
        cv.put("birthdate", birthdate);
        cv.put("city", city);
        cv.put("profile_image", profileImage);
        int result = db.update("users", cv, "id=?", new String[]{String.valueOf(id)});
        return result > 0;
    }
}

