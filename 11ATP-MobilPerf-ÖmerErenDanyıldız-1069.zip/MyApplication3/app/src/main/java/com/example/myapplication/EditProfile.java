package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditProfile extends AppCompatActivity {

    EditText etName, etSurname, etPassword, etBirthdate, etCity;
    ImageView ivProfile;
    Button btnSave, btnBack;

    DBHelper dbHelper;
    int userId;
    byte[] profileImageBytes;
    LinearLayout layoutProfilePics;
    ImageView imgProfile;
    int selectedImageResId = R.drawable.default_profile;

    int[] profileImages = {
            R.drawable.default_profile,
            R.drawable.profile2,
            R.drawable.profile3,
            R.drawable.profile4
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        imgProfile = findViewById(R.id.imgProfile);

        layoutProfilePics = findViewById(R.id.layoutProfilePics);

        for (int resId : profileImages) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(resId);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(200, 200);
            params.setMargins(16, 0, 16, 0);
            imageView.setLayoutParams(params);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8,8,8,8);




            imageView.setOnClickListener(v -> {
                selectedImageResId = resId;
                imgProfile.setImageResource(selectedImageResId);
                for (int i = 0; i < layoutProfilePics.getChildCount(); i++) {
                    layoutProfilePics.getChildAt(i).setBackgroundResource(0);
                }


            });

            layoutProfilePics.addView(imageView);

        }

        etName = findViewById(R.id.edtName);
        etSurname = findViewById(R.id.edtSurname);
        etPassword = findViewById(R.id.edtPassword);
        etBirthdate = findViewById(R.id.edtBirthdate);
        etCity = findViewById(R.id.edtCity);
        ivProfile = findViewById(R.id.imgProfile);
        btnSave = findViewById(R.id.btnSave);
        btnBack = findViewById(R.id.buttonBack);

        dbHelper = new DBHelper(this);
        userId = getIntent().getIntExtra("userId", -1);

        loadUserData();

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String surname = etSurname.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String birthdate = etBirthdate.getText().toString().trim();
            String city = etCity.getText().toString().trim();

            if (name.isEmpty() || surname.isEmpty() || password.isEmpty()) {
                Toast.makeText(EditProfile.this, "Ad, Soyad ve Şifre boş bırakılamaz!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = dbHelper.updateUser(userId, name, surname, password, birthdate, city, profileImageBytes);
            if (updated) {
                Toast.makeText(EditProfile.this, "Profil güncellendi.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(EditProfile.this, "Güncelleme başarısız!", Toast.LENGTH_SHORT).show();
            }
        });

        btnBack.setOnClickListener(v -> {
            finish();
        });


    }

    private void loadUserData() {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery("SELECT * FROM users WHERE id=?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            etName.setText(cursor.getString(cursor.getColumnIndexOrThrow("name")));
            etSurname.setText(cursor.getString(cursor.getColumnIndexOrThrow("surname")));
            etPassword.setText(cursor.getString(cursor.getColumnIndexOrThrow("password")));
            etBirthdate.setText(cursor.getString(cursor.getColumnIndexOrThrow("birthdate")));
            etCity.setText(cursor.getString(cursor.getColumnIndexOrThrow("city")));

            profileImageBytes = cursor.getBlob(cursor.getColumnIndexOrThrow("profile_image"));
            if (profileImageBytes != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(profileImageBytes, 0, profileImageBytes.length);
                ivProfile.setImageBitmap(bitmap);
            } else {
                ivProfile.setImageResource(R.drawable.default_profile);
            }
        }
        cursor.close();
    }
}

