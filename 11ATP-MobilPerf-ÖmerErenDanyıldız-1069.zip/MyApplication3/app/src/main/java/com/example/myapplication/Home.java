package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {

    ImageView ivProfile;
    Button ivEdit;
    TextView tvName, tvSurname, tvUsername, tvBirthdate, tvCity;
    DBHelper dbHelper;
    String username;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ivProfile = findViewById(R.id.imgProfile);
        ivEdit = findViewById(R.id.btnEditProfile);
        tvName = findViewById(R.id.tvName);
        tvSurname = findViewById(R.id.tvSurname);
        tvUsername = findViewById(R.id.tvUsername);
        tvCity = findViewById(R.id.tvCity);

        dbHelper = new DBHelper(this);

        username = getIntent().getStringExtra("username");
        loadUserData();

        ivEdit.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, EditProfile.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
            finish();
        });
    }

    private void loadUserData() {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery("SELECT * FROM users WHERE username=?", new String[]{username});
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            tvName.setText("Ad: " + cursor.getString(cursor.getColumnIndexOrThrow("name")));
            tvSurname.setText("Soyad: " + cursor.getString(cursor.getColumnIndexOrThrow("surname")));
            tvUsername.setText("Kullanıcı Adı: " + cursor.getString(cursor.getColumnIndexOrThrow("username")));
            tvCity.setText("Şehir: " + cursor.getString(cursor.getColumnIndexOrThrow("city")));

            byte[] imageBytes = cursor.getBlob(cursor.getColumnIndexOrThrow("profile_image"));
            if (imageBytes != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                ivProfile.setImageBitmap(bitmap);
            } else {
                ivProfile.setImageResource(R.drawable.default_profile);
            }
        }
        cursor.close();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadUserData();
    }
}
