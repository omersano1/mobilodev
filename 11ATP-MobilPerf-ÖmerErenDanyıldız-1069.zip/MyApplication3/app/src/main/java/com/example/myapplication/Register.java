package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.BitmapCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.ByteArrayOutputStream;

public class Register extends AppCompatActivity {
    LinearLayout layoutProfilePics;
    int selectedImageResId = R.drawable.default_profile;

    int[] profileImages = {
            R.drawable.default_profile,
            R.drawable.profile2,
            R.drawable.profile3,
            R.drawable.profile4

    };
    EditText edtName, edtSurname, edtUsername, edtPassword, edtBirthdate, edtCity;
    ImageView imgProfile;
    Button btnSubmit,buttonBack;

    DBHelper dbHelper;
    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DBHelper(this);

        edtName = findViewById(R.id.edtName);
        edtSurname = findViewById(R.id.edtSurname);
        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        edtBirthdate = findViewById(R.id.edtBirthdate);
        edtCity = findViewById(R.id.edtCity);
        imgProfile = findViewById(R.id.imgProfile);
        btnSubmit = findViewById(R.id.btnSubmit);


        buttonBack = findViewById(R.id.buttonBack);
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Register.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        layoutProfilePics = findViewById(R.id.layoutProfilePics);


        for (int resId : profileImages) {
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(resId);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(200, 200);
            params.setMargins(16, 0, 16, 0);
            imageView.setLayoutParams(params);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setPadding(8,8,8,8);



            imageView.setOnClickListener(v -> {
                selectedImageResId = resId;
                imgProfile.setImageResource(selectedImageResId);
                for (int i = 0; i < layoutProfilePics.getChildCount(); i++) {
                    layoutProfilePics.getChildAt(i).setBackgroundResource(0);
                }

            });

            layoutProfilePics.addView(imageView);

        }
        btnSubmit.setOnClickListener(v -> {
            String name = edtName.getText().toString();
            String surname = edtSurname.getText().toString();
            String username = edtUsername.getText().toString();
            String password = edtPassword.getText().toString();
            String birthdate = edtBirthdate.getText().toString();
            String city = edtCity.getText().toString();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(surname) || TextUtils.isEmpty(username)
                    || TextUtils.isEmpty(password) || TextUtils.isEmpty(birthdate) || TextUtils.isEmpty(city)) {
                Toast.makeText(Register.this, "Lütfen tüm alanları doldurun!", Toast.LENGTH_SHORT).show();
            } else {
                byte[] profileImage = imageViewToByte(imgProfile);
                if (dbHelper.insertUser(name, surname, username, password, birthdate, city, profileImage)) {
                    Toast.makeText(Register.this, "Kayıt başarılı!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Register.this, Login.class));
                } else {
                    Toast.makeText(Register.this, "Kayıt başarısız!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            imgProfile.setImageURI(imageUri);
        }
    }

    public byte[] imageViewToByte(ImageView imageView) {
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }





}

